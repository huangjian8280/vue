var express = require('express');
var router = express.Router();
var UserDAO = require('../dao/UserDAO');

/* GET users listing. */
//二级路由
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});
router.get('/validate',function(req,res){
    var username = req.query.username;
    // console.log("username",username);
    UserDAO.findByUsername(username,function(data){
        if(data.length > 0){
            res.send({status:0});
        }else{
            res.send({status:1});
        }
    });

});
router.post('/reg',function(req,res){
    //GET提交获取参数的方法
    // var username = req.query.username;
    // var pwd = req.query.pwd;

    //POST提交获取参数的方法
    var username = req.body.username;
    var pwd = req.body.pwd;
    var email = req.body.email;
    UserDAO.insert(username,pwd,function(){
        res.send("注册成功");
    });

});
router.post('/login',function(req,res){
    var username = req.body.username;
    var pwd = req.body.pwd;
    UserDAO.findByUsernameAndPwd(username,pwd,function(data){
        if(data.length > 0){
            res.send({status:1});
        }else{
            res.send({status:0});
        }
    });
});

module.exports = router;
