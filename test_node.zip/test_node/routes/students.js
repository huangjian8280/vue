var express = require('express');
var router = express.Router();
var StudentDAO = require('../dao/StudentDAO');

router.get('/showAll',function(req,res){
    var curpage = req.query.curpage;
    var eachpage = 5;
    var text = req.query.searchText;
    var option = {};
    if(text){
        option.name = {$regex:text}
    }

    StudentDAO.find(curpage,eachpage,option,function(data){
        res.send(data);
    });
});

router.post('/add',function(req,res){
    var name = req.body.name;
    var age = req.body.age;
    var gender = req.body.gender;
    StudentDAO.insert({name:name,age:age,gender:gender},function(){
        res.send("增加成功");
    });
});

router.post("/del",function(req,res){
    var id = req.body.id;
    StudentDAO.remove(id,function(){
        res.send("删除成功");
    });
});

router.get('/showById',function(req,res){
    var id = req.query.id;
    StudentDAO.findById(id,function(data){
        res.send(data[0]);
    });
});

router.post('/update',function(req,res){
    var id = req.body.id;
    var name = req.body.name;
    var age = req.body.age;
    var gender = req.body.gender;
    StudentDAO.update(id,{name:name,age:age,gender:gender},function(){
        res.send("修改成功");
    });
})

module.exports = router;
