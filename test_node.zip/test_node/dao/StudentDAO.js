var db = require("./database");

module.exports.find = function(curpage,eachpage,option,func){
    db.collection("students").findByPage(curpage,eachpage,option,func);
}

module.exports.findById = function(id,func){
    db.collection("students").find({_id:db.ObjectID(id)},func);
}

module.exports.insert = function(option,func){
    db.collection("students").insert(option,func);
}

module.exports.remove = function(id,func){
    db.collection("students").remove({_id:db.ObjectID(id)},func);
}

module.exports.update = function(id,option,func){
    db.collection("students").update({_id:db.ObjectID(id)},{$set:option},func);
}
