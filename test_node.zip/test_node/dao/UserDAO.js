var db = require("./database");

module.exports.findByUsername = function(username,func){
    console.log("username",username);
    db.collection("users").find({username:username},func);
}

module.exports.findByUsernameAndPwd = function(username,pwd,func){
    db.collection("users").find({username:username,pwd:pwd},func);
}

module.exports.insert = function(username,pwd,func){
    db.collection("users").insert({username:username,pwd:pwd},func);;
}
