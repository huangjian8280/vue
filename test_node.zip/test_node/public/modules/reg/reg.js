define(function(require,exports,module){
    var $ = require("jquery");
    var init = function(){
        $("#content").load("modules/reg/reg.html",function(){
            var isUsernameValid;
            var isPwdValid;
            var isConfirmPwdValid;
            var isEmailValid;
            $("#username").on("blur",function(){
                if(/^\w{6,20}$/.test($("#username").val())){
                    $.ajax({
                        type:"get",
                        url:"/users/validate",
                        data:{username:$("#username").val()},
                        success:function(data){
                            if(data.status == 0){
                                $("#username").next().html("重名，不可用").css({color:"red"});
                            }else{
                                $("#username").next().html("可用").css({color:"green"});
                                isUsernameValid = true;
                            }
                        }
                    });

                }else{
                    $("#username").next().html("格式不正确").css({color:"red"});
                }
            });

            $("#pwd").on("blur",function(){
                if(/^.{6,20}$/.test($("#pwd").val())){
                    $("#pwd").next().html("格式正确").css({color:"green"});
                    isPwdValid = true;
                }else{
                    $("#pwd").next().html("格式不正确").css({color:"red"});
                }
            });

            $("#confirmPwd").on("blur",function(){
                if($("#pwd").val() == $("#confirmPwd").val()){
                    $("#confirmPwd").next().html("密码一致").css({color:"green"});
                    isConfirmPwdValid = true;
                }else{
                    $("#confirmPwd").next().html("两次密码不一致").css({color:"red"});
                }
            });

            $(":button").on("click",function(){
                if(isUsernameValid && isPwdValid && isConfirmPwdValid){
                    $.ajax({
                        type:"post",
                        url:"/users/reg",
                        data:{
                            username:$("#username").val(),
                            pwd:$("#pwd").val(),
                            email:$("#email").val()
                        },
                        success:function(){
                            alert("注册成功");
                            var login = require("login");
                            login.init();
                        }
                    });
                }else{
                    alert("请先验证");
                }

            });
        });
    }
    module.exports.init = init;
})
