define(function(require,exports,module){
    var $ = require("jquery");
    var init = function(){
        $("#content").load("modules/login/login.html",function(){

        });
    }
    module.exports.init = init;
})
