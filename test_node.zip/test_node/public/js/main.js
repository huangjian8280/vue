define(function(require){
    var reg = require("reg");
    var login = require("login");
    reg.init();
    // login.init();
});
